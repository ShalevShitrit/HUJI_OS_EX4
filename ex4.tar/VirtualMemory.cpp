#include "VirtualMemory.h"
#include "PhysicalMemory.h"

// Constants
#define INITIAL_FRAME_VALUE 0
#define START_FRAME 0

// Struct Definitions
typedef struct {
    word_t max_frame;
    word_t max_cyclic_leaf;
    word_t max_cyclic_frame;
    word_t max_cyclic_dist;
    word_t frame_with_zeros;
} TraversalResult;

// Helper Functions
uint64_t combine_binary(uint64_t high, uint64_t low)
{
    return (high << OFFSET_WIDTH) + low;
}

word_t calculate_cyclic_distance(word_t in_page, word_t ref_page)
{
    int diff = in_page - ref_page;
    int abs_diff = diff > 0 ? diff : -diff;
    return (NUM_PAGES - abs_diff) < abs_diff ? (word_t)(NUM_PAGES - abs_diff) : abs_diff;
}

uint64_t physical_address(word_t frame, word_t offset)
{
    return (frame * PAGE_SIZE) + offset;
}

void clear_frame(word_t frame)
{
    for (int i = 0; i < PAGE_SIZE; ++i)
    {
        PMwrite(frame * PAGE_SIZE + i, INITIAL_FRAME_VALUE);
    }
}

void process_leaf(TraversalResult* result, word_t frame, uint64_t page, uint64_t path)
{
    if (frame > result->max_frame)
        result->max_frame = frame;

    word_t cyclic_dist = calculate_cyclic_distance((word_t)page, (word_t)path);
    if (cyclic_dist > result->max_cyclic_dist)
    {
        result->max_cyclic_dist = cyclic_dist;
        result->max_cyclic_leaf = (word_t)path;
        result->max_cyclic_frame = frame;
    }
}

void traverse_tree(uint64_t parent, uint64_t page, TraversalResult* result, word_t frame = START_FRAME, int depth = -1, uint64_t path = 0)
{
    depth++;
    if (depth == TABLES_DEPTH)
    {
        process_leaf(result, frame, page, path);
        return;
    }

    int zero_count = 0;
    for (int i = 0; i < PAGE_SIZE; ++i)
    {
        word_t child;
        PMread(frame * PAGE_SIZE + i, &child);
        if (child == 0)
        {
            zero_count++;
            continue;
        }
        traverse_tree(parent, page, result, child, depth, combine_binary(path, i));
    }

    if (zero_count == PAGE_SIZE && frame != (word_t)parent && frame < result->frame_with_zeros)
    {
        result->frame_with_zeros = frame;
    }

    if (frame > result->max_frame)
        result->max_frame = frame;
}

void remove_frame(word_t target_frame, word_t current_frame = START_FRAME, int depth = -1)
{
    depth++;
    if (depth == TABLES_DEPTH) return;

    for (int i = 0; i < PAGE_SIZE; ++i)
    {
        word_t child;
        PMread(current_frame * PAGE_SIZE + i, &child);

        if (child == 0) continue;
        if (child == target_frame)
        {
            PMwrite(current_frame * PAGE_SIZE + i, INITIAL_FRAME_VALUE);
            return;
        }
        remove_frame(target_frame, child, depth);
    }
}

word_t locate_available_frame(uint64_t parent, uint64_t page)
{
    TraversalResult result = {0, 0, 0, 0, NUM_FRAMES};
    traverse_tree(parent, page, &result);

    if (result.frame_with_zeros != NUM_FRAMES)
    {
        remove_frame(result.frame_with_zeros);
        return result.frame_with_zeros;
    }
    if (result.max_frame < NUM_FRAMES - 1)
    {
        return result.max_frame + 1;
    }
    PMevict(result.max_cyclic_frame, result.max_cyclic_leaf);
    remove_frame(result.max_cyclic_frame);
    return result.max_cyclic_frame;
}

word_t resolve_frame(uint64_t virtualAddress)
{
    word_t child = 0;
    word_t parent = 0;
    uint64_t page = virtualAddress >> OFFSET_WIDTH;

    for (int i = 0; i < TABLES_DEPTH; ++i)
    {
        uint64_t level = (virtualAddress >> ((TABLES_DEPTH - i) * OFFSET_WIDTH)) & ((1ll << OFFSET_WIDTH) - 1);
        PMread(parent * PAGE_SIZE + level, &child);
        if (child == 0)
        {
            child = locate_available_frame(parent, page);
            if (i < TABLES_DEPTH - 1) clear_frame(child);
            PMwrite(parent * PAGE_SIZE + level, child);
        }
        parent = child;
    }
    PMrestore(child, page);
    return parent * PAGE_SIZE + virtualAddress % PAGE_SIZE;
}

// External Functions
void VMinitialize()
{
    clear_frame(START_FRAME);
}

int VMread(uint64_t virtualAddress, word_t* value)
{
    if (virtualAddress >= VIRTUAL_MEMORY_SIZE) return 0;
    word_t frame_addr = resolve_frame(virtualAddress);
    PMread(frame_addr, value);
    return 1;
}

int VMwrite(uint64_t virtualAddress, word_t value)
{
    if (virtualAddress >= VIRTUAL_MEMORY_SIZE) return 0;
    word_t frame_addr = resolve_frame(virtualAddress);
    PMwrite(frame_addr, value);
    return 1;
}
